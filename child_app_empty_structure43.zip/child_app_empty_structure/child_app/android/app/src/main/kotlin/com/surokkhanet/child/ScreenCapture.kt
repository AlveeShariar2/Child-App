package com.surokkhanet.child

import android.graphics.Bitmap
import android.media.Image
import android.media.ImageReader
import android.os.Environment
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date

object ScreenCapture {

    fun captureImage(image: Image): String? {
        val buffer: ByteBuffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        
        return try {
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
            val fileName = "SCR_$timeStamp.jpg"
            val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), fileName)
            
            FileOutputStream(file).use { fos ->
                fos.write(bytes)
                fos.flush()
            }
            
            file.absolutePath
        } catch (e: Exception) {
            Log.e("ScreenCapture", "Error saving image: ${e.message}")
            null
        }
    }
}