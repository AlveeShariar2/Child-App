package com.surokkhanet.child

import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.util.DisplayMetrics
import android.util.Log
import android.view.Surface

object ScreenStreamer {
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var isStreaming = false

    fun startStreaming(context: Context, resultCode: Int, data: Intent) {
        if (isStreaming) {
            Log.w("ScreenStreamer", "স্ট্রিমিং ইতিমধ্যেই চলছে")
            return
        }

        try {
            val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)
            
            val metrics = context.resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val dpi = metrics.densityDpi
            
            // Create ImageReader for screen frames
            imageReader = ImageReader.newInstance(width, height, ImageReaderFormat.RGBA_8888, 3)
            
            // Create virtual display
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "ChildSafetyStream",
                width,
                height,
                dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                null
            )
            
            // Set up frame capture
            setupFrameCapture()
            
            isStreaming = true
            Log.i("ScreenStreamer", "স্ক্রিন স্ট্রিমিং শুরু হয়েছে: ${width}x${height}")
        } catch (e: Exception) {
            Log.e("ScreenStreamer", "স্ট্রিমিং শুরু করতে ব্যর্থ: ${e.message}")
        }
    }

    fun stopStreaming() {
        if (!isStreaming) return
        
        try {
            virtualDisplay?.release()
            mediaProjection?.stop()
            imageReader?.close()
            
            virtualDisplay = null
            mediaProjection = null
            imageReader = null
            isStreaming = false
            
            Log.i("ScreenStreamer", "স্ক্রিন স্ট্রিমিং বন্ধ হয়েছে")
        } catch (e: Exception) {
            Log.e("ScreenStreamer", "স্ট্রিমিং বন্ধ করতে ব্যর্থ: ${e.message}")
        }
    }

    private fun setupFrameCapture() {
        imageReader?.setOnImageAvailableListener({ reader ->
            // Acquire the latest image
            val image = reader.acquireLatestImage()
            image?.use {
                // Process image frames here
                // Convert to video stream or send to server
                Log.d("ScreenStreamer", "ফ্রেম ক্যাপচার করা হয়েছে: ${it.width}x${it.height}")
            }
        }, null)
    }

    companion object {
        // For Android versions before API 23
        private const val ImageReaderFormat_RGBA_8888 = 0x1
    }
}