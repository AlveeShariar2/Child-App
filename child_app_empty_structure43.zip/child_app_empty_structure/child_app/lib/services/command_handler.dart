import 'package:firebase_database/firebase_database.dart';
import 'package:child_app/utils/constants.dart';
import 'package:child_app/services/native_channel.dart'; // নেটিভ চ্যানেল ইম্পোর্ট

class CommandHandler {
  static void init() async {
    final deviceId = await Constants.getDeviceId();
    final ref = FirebaseDatabase.instance.ref('devices/$deviceId/commands');
    
    ref.onChildAdded.listen((event) async {
      final command = event.snapshot.value as Map<dynamic, dynamic>;
      if (command['status'] == 'pending') {
        await _processCommand(event.snapshot.key!, command, deviceId);
      }
    });
  }

  static Future<void> _processCommand(String commandId, Map<dynamic, dynamic> command, String deviceId) async {
    final ref = FirebaseDatabase.instance.ref('devices/$deviceId/commands/$commandId');
    
    try {
      // কমান্ড টাইপ অনুযায়ী প্রসেসিং
      switch (command['type']) {
        case 'lock_device':
          await NativeChannel.lockDevice(); // নেটিভ ডিভাইস লক
          await ref.update({'status': 'completed'});
          break;
          
        case 'take_photo':
          await NativeChannel.takeFrontPhoto(); // ফ্রন্ট ক্যামেরা দিয়ে ছবি তোলা
          await ref.update({'status': 'completed'});
          break;
          
        case 'get_location':
          // লোকেশন রিট্রিভাল ইম্প্লিমেন্ট করুন (পরবর্তীতে যোগ করুন)
          await ref.update({'status': 'completed'});
          break;
          
        default:
          await ref.update({'status': 'failed', 'error': 'অজানা কমান্ড টাইপ'});
      }
    } catch (e) {
      await ref.update({'status': 'failed', 'error': e.toString()});
    }
  }
}