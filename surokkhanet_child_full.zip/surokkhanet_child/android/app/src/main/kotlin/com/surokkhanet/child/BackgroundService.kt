// BackgroundService.kt content
