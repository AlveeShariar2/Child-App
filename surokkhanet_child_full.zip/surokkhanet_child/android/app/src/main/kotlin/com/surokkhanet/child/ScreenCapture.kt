// ScreenCapture.kt content
