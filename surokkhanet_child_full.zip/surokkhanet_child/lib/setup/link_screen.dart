// link_screen.dart content
