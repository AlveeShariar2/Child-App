// firebase_service.dart content
