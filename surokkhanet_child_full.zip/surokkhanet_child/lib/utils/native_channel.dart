// native_channel.dart content
