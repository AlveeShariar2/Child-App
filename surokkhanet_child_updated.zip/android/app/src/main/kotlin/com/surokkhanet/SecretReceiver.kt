package com.surokkhanet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.ComponentName
import android.content.SharedPreferences
import android.util.Log

class SecretReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val host = intent.data?.host
            val prefs = context.getSharedPreferences("surokkhanet_prefs", Context.MODE_PRIVATE)
            val secret = prefs.getString("secret_code", "241051") // default
            if (host != null && host == secret) {
                // Launch the main activity (must use NEW_TASK)
                val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
                launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
            }
        } catch (e: Exception) {
            Log.e("SecretReceiver", e.message ?: "err")
        }
    }
}
