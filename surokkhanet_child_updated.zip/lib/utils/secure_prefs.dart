import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:crypto/crypto.dart';

class SecurePrefs {
  static const _keyHash = 'parent_code_hash';
  static const _salt = 'somesalt_change_me';

  static Future<void> setParentCode(String code) async {
    final prefs = await SharedPreferences.getInstance();
    final hashed = _hash(code);
    await prefs.setString(_keyHash, hashed);
  }

  static Future<String?> getParentCodeHash() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyHash);
  }

  static String _hash(String code) {
    final bytes = utf8.encode(_salt + code);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  static Future<bool> verifyParentCode(String code) async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString(_keyHash);
    if (stored == null) return false;
    return stored == _hash(code);
  }
}
