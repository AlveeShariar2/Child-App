import 'package:flutter/material.dart';
import '../utils/secure_prefs.dart';
import '../utils/native_channel.dart';

class WelcomeScreen extends StatefulWidget {
  @override
  _WelcomeScreenState createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  String _code = "241051";
  @override
  void initState() {
    super.initState();
    _init();
  }
  _init() async {
    await SecurePrefs.setParentCode(_code); // default for demo, real app should get from parent link flow
    await NativeChannel.hideAppIcon();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text('SurokkhaNet Child - setup complete')),
    );
  }
}
