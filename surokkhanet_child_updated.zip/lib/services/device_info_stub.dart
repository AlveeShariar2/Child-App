// Simple stub for device id retrieval - replace with actual implementation
class DeviceInfo {
  static Future<String> getDeviceId() async {
    return "demo_device_id_001";
  }
}
