import 'package:flutter/material.dart';
import 'package:child_app/setup/welcome_screen.dart';
import 'package:child_app/utils/stealth_handler.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  
  // Check if stealth mode is active
  final isStealthActive = await StealthHandler.isStealthActive();
  
  runApp(MyApp(
    showUI: !isStealthActive,
  ));
}

class MyApp extends StatelessWidget {
  final bool showUI;
  
  const MyApp({super.key, required this.showUI});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Child Safety',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: showUI ? const WelcomeScreen() : Container(),
      debugShowCheckedModeBanner: false,
    );
  }
}