package com.surokkhanet.child

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class NotificationCatcher : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val packageName = event.packageName.toString()
            val message = event.text.joinToString(", ")
            Log.d("Notification", "Package: $packageName, Message: $message")
            // Send to Firebase or backend
        }
    }

    override fun onInterrupt() {}
}