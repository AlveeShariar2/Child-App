package com.surokkhanet.child

import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.content.Context
import android.content.Intent

object ScreenStreamer {
    private var mediaProjection: MediaProjection? = null
    
    fun startStreaming(context: Context, resultCode: Int, data: Intent) {
        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)
        // Start capturing and streaming
    }
    
    fun stopStreaming() {
        mediaProjection?.stop()
        mediaProjection = null
    }
}