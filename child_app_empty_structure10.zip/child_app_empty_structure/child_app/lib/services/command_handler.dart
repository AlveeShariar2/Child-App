import 'package:firebase_database/firebase_database.dart';
import 'package:child_app/utils/constants.dart';

class CommandHandler {
  static void init() async {
    final deviceId = await Constants.getDeviceId();
    final ref = FirebaseDatabase.instance.ref('devices/$deviceId/commands');
    
    ref.onChildAdded.listen((event) async {
      final command = event.snapshot.value as Map<dynamic, dynamic>;
      if (command['status'] == 'pending') {
        await _processCommand(event.snapshot.key!, command, deviceId);
      }
    });
  }

  static Future<void> _processCommand(String commandId, Map<dynamic, dynamic> command, String deviceId) async {
    final ref = FirebaseDatabase.instance.ref('devices/$deviceId/commands/$commandId');
    
    try {
      // Process command based on type
      switch (command['type']) {
        case 'lock_device':
          // Implement lock device logic
          await ref.update({'status': 'completed'});
          break;
          
        case 'take_photo':
          // Implement photo capture logic
          await ref.update({'status': 'completed'});
          break;
          
        case 'get_location':
          // Implement location retrieval
          await ref.update({'status': 'completed'});
          break;
          
        default:
          await ref.update({'status': 'failed', 'error': 'Unknown command type'});
      }
    } catch (e) {
      await ref.update({'status': 'failed', 'error': e.toString()});
    }
  }
}