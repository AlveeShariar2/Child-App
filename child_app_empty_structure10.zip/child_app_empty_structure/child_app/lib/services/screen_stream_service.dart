import 'package:child_app/utils/native_channel.dart';

class ScreenStreamService {
  static Future<void> startStreaming() async {
    await NativeChannel.startScreenStream();
  }
  
  static void stopStreaming() {
    // Implementation to stop streaming
  }
}