import 'package:geolocator/geolocator.dart';
import 'package:child_app/utils/constants.dart';
import 'package:firebase_database/firebase_database.dart';

class GeofenceService {
  static void initializeGeofences(List<Map<String, dynamic>> geofences) {
    // Setup geofences
  }
  
  static void _onGeofenceEvent(String geofenceId, bool enter) {
    final ref = FirebaseDatabase.instance.ref('geofence_events');
    ref.push().set({
      'geofenceId': geofenceId,
      'event': enter ? 'enter' : 'exit',
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }
}