package com.surokkhanet.child

import android.hardware.Camera
import java.io.FileOutputStream

object CameraController {
    private var camera: Camera? = null
    
    fun takeFrontPhoto(): String? {
        return try {
            camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT)
            camera?.let {
                it.takePicture(null, null) { data, _ ->
                    val path = "/sdcard/DCIM/front_photo.jpg"
                    FileOutputStream(path).use { fos ->
                        fos.write(data)
                    }
                    camera?.release()
                    camera = null
                    return@takePicture path
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }
}