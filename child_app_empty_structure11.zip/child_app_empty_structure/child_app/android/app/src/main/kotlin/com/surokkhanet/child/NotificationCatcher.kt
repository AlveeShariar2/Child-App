package com.surokkhanet.child

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class NotificationCatcher : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val packageName = event.packageName.toString()
            val message = event.text.joinToString()
            // ফায়ারবেজে সেন্ড করুন
            sendToFirebase(packageName, message)
        }
    }

    private fun sendToFirebase(packageName: String, message: String) {
        val data = hashMapOf(
            "package" to packageName,
            "message" to message,
            "timestamp" to System.currentTimeMillis()
        )

        Firebase.firestore.collection("notifications")
            .add(data)
            .addOnSuccessListener {
                Log.d("Firebase", "নোটিফিকেশন সেভ হয়েছে")
            }
            .addOnFailureListener { e ->
                Log.e("Firebase", "সেভ করতে সমস্যা: ${e.message}")
            }
    }

    override fun onInterrupt() {
        Log.d("Accessibility", "সার্ভিস বাধাপ্রাপ্ত হয়েছে")
    }
}