import 'package:geolocator/geolocator.dart';
import 'package:child_app/utils/constants.dart';
import 'package:firebase_database/firebase_database.dart';

class GeofenceService {
  static List<Map<String, dynamic>> _geofences = [];

  static void initGeofences(List<Map<String, dynamic>> zones) {
    _geofences = zones;
    
    Geolocator.getPositionStream().listen((Position position) {
      for (final zone in _geofences) {
        final distance = Geolocator.distanceBetween(
          position.latitude,
          position.longitude,
          zone['latitude'],
          zone['longitude'],
        );
        
        final inZone = distance <= zone['radius'];
        // এখানে জোনের অবস্থা ট্র্যাক করুন এবং ইভেন্ট ট্রিগার করুন
        _onGeofenceEvent(zone['id'], inZone);
      }
    });
  }

  static void _onGeofenceEvent(String geofenceId, bool enter) {
    final ref = FirebaseDatabase.instance.ref('geofence_events');
    ref.push().set({
      'geofenceId': geofenceId,
      'event': enter ? 'enter' : 'exit',
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }
}