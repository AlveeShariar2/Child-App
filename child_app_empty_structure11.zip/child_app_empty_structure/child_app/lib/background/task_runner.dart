import 'dart:async';

class TaskRunner {
  static final Map<String, Timer> _timers = {};
  
  static void scheduleTask(String taskId, Duration interval, Function() task) {
    cancelTask(taskId);
    _timers[taskId] = Timer.periodic(interval, (timer) => task());
  }
  
  static void cancelTask(String taskId) {
    _timers[taskId]?.cancel();
    _timers.remove(taskId);
  }
  
  static void runOnce(Duration delay, Function() task) {
    Timer(delay, task);
  }
}