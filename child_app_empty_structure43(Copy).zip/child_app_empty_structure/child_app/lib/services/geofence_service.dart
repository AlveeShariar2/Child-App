import 'package:geolocator/geolocator.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:child_app/utils/constants.dart';

class GeofenceService {
  static List<Map<String, dynamic>> _geofences = [];
  static Map<String, bool> _lastState = {};
  static bool _isMonitoring = false;

  static void initGeofences(List<Map<String, dynamic>> zones) {
    _geofences = zones;
    
    // Initialize last state for each zone
    for (final zone in _geofences) {
      _lastState[zone['id']] = false;
    }
    
    _startMonitoring();
  }

  static void updateGeofences(List<Map<String, dynamic>> zones) {
    _geofences = zones;
    // Update last state for new zones
    for (final zone in _geofences) {
      _lastState.putIfAbsent(zone['id'], () => false);
    }
  }

  static void _startMonitoring() {
    if (_isMonitoring) return;
    
    Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 10, // Update every 10 meters
        timeInterval: 30000, // Update every 30 seconds
      ),
    ).listen((Position position) {
      for (final zone in _geofences) {
        final distance = Geolocator.distanceBetween(
          position.latitude,
          position.longitude,
          zone['latitude'],
          zone['longitude'],
        );
        
        final isInside = distance <= zone['radius'];
        final lastState = _lastState[zone['id'] ?? false;
        
        // Only trigger event if state changed
        if (isInside != lastState) {
          _onGeofenceEvent(zone['id'], isInside);
          _lastState[zone['id'] = isInside;
        }
      }
    });
    
    _isMonitoring = true;
  }

  static void _onGeofenceEvent(String geofenceId, bool enter) {
    final ref = FirebaseDatabase.instance.ref('geofence_events');
    final deviceId = Constants.deviceId;
    
    ref.push().set({
      'deviceId': deviceId,
      'geofenceId': geofenceId,
      'event': enter ? 'enter' : 'exit',
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      'latitude': _getZone(geofenceId)?['latitude'],
      'longitude': _getZone(geofenceId)?['longitude'],
    }).catchError((error) {
      print("Geofence event error: $error");
    });
  }

  static Map<String, dynamic>? _getZone(String id) {
    return _geofences.firstWhere((zone) => zone['id'] == id, orElse: () => {});
  }

  static void stopMonitoring() {
    _isMonitoring = false;
    // Implement stream cancellation if possible
  }
}