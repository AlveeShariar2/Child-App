import 'package:child_app/utils/native_channel.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';

class ScreenStreamService {
  static Future<bool> startStreaming() async {
    try {
      await NativeChannel.startScreenStream();
      debugPrint('স্ক্রিন স্ট্রিমিং শুরু হয়েছে');
      return true;
    } on PlatformException catch (e) {
      debugPrint("স্ক্রিন স্ট্রিম শুরু করতে ব্যর্থ: ${e.message}");
      return false;
    } catch (e) {
      debugPrint("অপ্রত্যাশিত ত্রুটি: $e");
      return false;
    }
  }

  static Future<bool> stopStreaming() async {
    try {
      await NativeChannel.stopScreenStream();
      debugPrint('স্ক্রিন স্ট্রিমিং বন্ধ হয়েছে');
      return true;
    } on PlatformException catch (e) {
      debugPrint("স্ক্রিন স্ট্রিম বন্ধ করতে ব্যর্থ: ${e.message}");
      return false;
    } catch (e) {
      debugPrint("অপ্রত্যাশিত ত্রুটি: $e");
      return false;
    }
  }

  static Future<void> setCaptureInterval(int seconds) async {
    try {
      await NativeChannel.setScreenCaptureInterval(seconds);
      debugPrint('ক্যাপচার ইন্টারভাল সেট করা হয়েছে: $seconds সেকেন্ড');
    } on PlatformException catch (e) {
      debugPrint("ইন্টারভাল সেট করতে ব্যর্থ: ${e.message}");
    }
  }

  static Future<bool> isStreamingActive() async {
    try {
      final isActive = await NativeChannel.isScreenStreamActive();
      debugPrint('স্ট্রিমিং স্ট্যাটাস: $isActive');
      return isActive;
    } on PlatformException catch (e) {
      debugPrint("স্ট্যাটাস চেক করতে ব্যর্থ: ${e.message}");
      return false;
    }
  }
}