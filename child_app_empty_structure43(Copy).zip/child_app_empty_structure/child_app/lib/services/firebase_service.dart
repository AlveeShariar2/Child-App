import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';

class FirebaseService {
  static Future<void> init() async {
    await Firebase.initializeApp();
  }

  static DatabaseReference getDeviceRef(String deviceId) {
    return FirebaseDatabase.instance.ref('devices/$deviceId');
  }

  static Future<void> sendCommand(String deviceId, String commandType) async {
    final ref = FirebaseDatabase.instance.ref('devices/$deviceId/commands');
    await ref.push().set({
      'type': commandType,
      'status': 'pending',
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }
}