import 'dart:async';

class TaskRunner {
  static final Map<String, Timer> _tasks = {};
  static final Map<String, DateTime> _lastExecution = {};

  static void schedule({
    required String taskId,
    required Duration interval,
    required Function() task,
    bool immediate = false,
  }) {
    // বিদ্যমান টাস্ক বাতিল করুন
    cancel(taskId);
    
    // অবিলম্বে এক্সিকিউট করার অপশন
    if (immediate) {
      task();
      _lastExecution[taskId] = DateTime.now();
    }
    
    // নতুন টাস্ক শিডিউল করুন
    _tasks[taskId] = Timer.periodic(interval, (timer) {
      task();
      _lastExecution[taskId] = DateTime.now();
    });
  }

  static void cancel(String taskId) {
    _tasks[taskId]?.cancel();
    _tasks.remove(taskId);
    _lastExecution.remove(taskId);
  }

  static Future<void> runOnce({
    required Duration delay,
    required Function() task,
    String? taskId,
  }) async {
    if (taskId != null && _tasks.containsKey(taskId)) {
      return;
    }
    
    final completer = Completer<void>();
    final timer = Timer(delay, () {
      task();
      if (taskId != null) {
        _tasks.remove(taskId);
      }
      completer.complete();
    });
    
    if (taskId != null) {
      _tasks[taskId] = timer;
    }
    
    return completer.future;
  }

  static DateTime? lastExecution(String taskId) {
    return _lastExecution[taskId];
  }

  static void cancelAll() {
    for (final timer in _tasks.values) {
      timer.cancel();
    }
    _tasks.clear();
    _lastExecution.clear();
  }
}