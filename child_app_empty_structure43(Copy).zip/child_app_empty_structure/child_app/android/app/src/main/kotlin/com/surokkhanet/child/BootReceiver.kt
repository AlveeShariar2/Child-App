package com.surokkhanet.child

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // ব্যাকগ্রাউন্ড সার্ভিস রিস্টার্ট করুন
            val serviceIntent = Intent(context, BackgroundService::class.java)
            ContextCompat.startForegroundService(context, serviceIntent)
            
            // অ্যাক্সেসিবিলিটি সার্ভিস রিস্টার্ট করুন
            val accessibilityIntent = Intent(context, ChildAccessibilityService::class.java)
            context.startService(accessibilityIntent)
            
            // স্টিলথ মোড চেক করুন
            if (StealthHandler.isStealthActive(context)) {
                // স্টিলথ মোড সক্রিয় থাকলে আইকন হাইড করুন
                NativeChannel.hideAppIcon(context)
            }
        }
    }
}