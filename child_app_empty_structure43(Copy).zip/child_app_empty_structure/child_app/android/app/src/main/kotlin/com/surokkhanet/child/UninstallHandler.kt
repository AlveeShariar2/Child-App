package com.surokkhanet.child

import android.annotation.SuppressLint
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class UninstallProtectionReceiver : DeviceAdminReceiver() {

    companion object {
        private const val TAG = "UninstallProtection"

        // এই ফাংশনটি দিয়ে অ্যাপের জন্য ডিভাইস অ্যাডমিন চালু করতে হবে
        fun requestAdminPermission(context: Context) {
            val devicePolicyManager = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val adminComponent = ComponentName(context, UninstallProtectionReceiver::class.java)

            // যদি ডিভাইস অ্যাডমিন আগে থেকেই চালু না থাকে
            if (!devicePolicyManager.isAdminActive(adminComponent)) {
                // ব্যবহারকারীকে ডিভাইস অ্যাডমিন চালু করার জন্য অনুরোধ জানানো হচ্ছে
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                    putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "অ্যাপটিকে আনইনস্টল হওয়া থেকে রক্ষা করতে এবং সুরক্ষা নিশ্চিত করতে এই অনুমতি প্রয়োজন।"
                    )
                }
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }
        }
    }

    // যখন ব্যবহারকারী ডিভাইস অ্যাডমিন নিষ্ক্রিয় করার চেষ্টা করবে, তখন এই ফাংশনটি কাজ করবে
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        // ব্যবহারকারীকে একটি সতর্কবার্তা দেখানো হচ্ছে
        val message = "সতর্কতা: এটি নিষ্ক্রিয় করলে অ্যাপের সুরক্ষা চলে যাবে এবং অ্যাপটি আনইনস্টল করা যাবে।"

        // Firebase-এ একটি লগ পাঠানো হচ্ছে যে কেউ আনইনস্টল করার চেষ্টা করছে
        logUninstallAttempt(context)

        return message
    }

    // কেউ ডিভাইস অ্যাডমিন নিষ্ক্রিয় করে দিলে এই ফাংশনটি কল হবে
    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.w(TAG, "Device admin has been disabled!")
        // এখানে আপনি চাইলে আবার অ্যাডমিন চালু করার জন্য অনুরোধ জানাতে পারেন
    }

    // কেউ সফলভাবে ডিভাইস অ্যাডমিন চালু করলে এই ফাংশনটি কল হবে
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.d(TAG, "Device admin has been enabled.")
    }

    // আনইনস্টল করার চেষ্টা হলে Firebase-এ লগ পাঠানোর জন্য এই ফাংশন
    private fun logUninstallAttempt(context: Context) {
        val deviceId = getDeviceId(context)
        val attemptDetails = hashMapOf(
            "deviceId" to deviceId,
            "type" to "uninstall_attempt", // চেষ্টার ধরন
            "timestamp" to System.currentTimeMillis(),
            "androidVersion" to Build.VERSION.RELEASE,
            "deviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}"
        )

        Firebase.firestore.collection("security_alerts")
            .add(attemptDetails)
            .addOnSuccessListener {
                Log.d(TAG, "Uninstall attempt logged successfully for device: $deviceId")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Failed to log uninstall attempt: ${e.message}")
            }
    }

    // ডিভাইসের একটি স্বতন্ত্র আইডি (Unique ID) বের করার জন্য এই ফাংশন
    @SuppressLint("HardwareIds")
    private fun getDeviceId(context: Context): String {
        return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
    }
}