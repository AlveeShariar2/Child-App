package com.surokkhanet.child

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.provider.CallLog
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.google.firebase.database.FirebaseDatabase
import java.util.Date

object CallLogMonitor {
    fun fetchAndUpload(context: Context) {
        // কল লগ পড়ার অনুমতি আছে কিনা তা পরীক্ষা করা হচ্ছে
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_CALL_LOG
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // অনুমতি না থাকলে ফাংশন থেকে বেরিয়ে যাবে
            return
        }

        val resolver: ContentResolver = context.contentResolver
        // ফোনের কল লগ থেকে ডেটা আনা হচ্ছে এবং তারিখ অনুযায়ী সাজানো হচ্ছে
        val cursor: Cursor? = resolver.query(
            CallLog.Calls.CONTENT_URI,
            null,
            null,
            null,
            CallLog.Calls.DATE + " DESC"
        ) ?: return // যদি কোনো কল লগ না থাকে, তাহলে এখান থেকেই বেরিয়ে যাবে

        cursor.use {
            // যদি কার্সারে অন্তত একটি কল লগ থাকে
            if (it.moveToFirst()) {
                // ডেটা কলামের ইন্ডেক্স নম্বরগুলো নিয়ে নেওয়া হচ্ছে
                val numberIndex = it.getColumnIndex(CallLog.Calls.NUMBER)
                val typeIndex = it.getColumnIndex(CallLog.Calls.TYPE)
                val dateIndex = it.getColumnIndex(CallLog.Calls.DATE)
                val durationIndex = it.getColumnIndex(CallLog.Calls.DURATION)

                // Firebase ডেটাবেসের সাথে সংযোগ স্থাপন করা হচ্ছে
                val db = FirebaseDatabase.getInstance()
                // প্রতিটি ডিভাইসের জন্য আলাদাভাবে কল লগ সেভ করার জন্য Device ID ব্যবহার করা হচ্ছে
                val ref = db.getReference("call_logs/${context.getDeviceId()}")

                // সব কল লগ শেষ না হওয়া পর্যন্ত লুপ চলতে থাকবে
                do {
                    val number = it.getString(numberIndex) ?: "Unknown"
                    val type = when (it.getInt(typeIndex)) {
                        CallLog.Calls.INCOMING_TYPE -> "Incoming"
                        CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
                        CallLog.Calls.MISSED_TYPE -> "Missed"
                        else -> "Unknown"
                    }
                    // তারিখকে লং (Long) টাইপে নেওয়া হচ্ছে, যা ডেটাবেসের জন্য ভালো
                    val date = Date(it.getLong(dateIndex))
                    val duration = it.getLong(durationIndex)

                    // Firebase ডেটাবেসে ডেটা পাঠানো হচ্ছে
                    ref.push().setValue(mapOf(
                        "number" to number,
                        "type" to type,
                        "date" to date.time, // তারিখকে Timestamp হিসাবে সেভ করা হচ্ছে
                        "duration" to duration
                    ))
                } while (it.moveToNext())
            }
        }
    }
}

// ডিভাইসের একটি স্বতন্ত্র আইডি (Unique ID) বের করার জন্য এই ফাংশনটি তৈরি করা হয়েছে
@SuppressLint("HardwareIds")
fun Context.getDeviceId(): String {
    return Settings.Secure.getString(
        contentResolver,
        Settings.Secure.ANDROID_ID
    )
}