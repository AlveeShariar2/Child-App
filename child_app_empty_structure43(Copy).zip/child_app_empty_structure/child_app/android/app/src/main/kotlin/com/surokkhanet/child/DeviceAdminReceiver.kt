package com.surokkhanet.child

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast

class DeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        showToast(context, "ডিভাইস অ্যাডমিন সক্রিয় হয়েছে")
    }

    override fun onDisabled(context: Context, intent: Intent) {
        showToast(context, "ডিভাইস অ্যাডমিন নিষ্ক্রিয় হয়েছে")
    }

    override fun onLockTaskModeEntering(context: Context, intent: Intent, pkg: String) {
        showToast(context, "কিওস্ক মোড সক্রিয় হয়েছে")
    }

    override fun onLockTaskModeExiting(context: Context, intent: Intent) {
        showToast(context, "কিওস্ক মোড নিষ্ক্রিয় হয়েছে")
    }

    override fun onPasswordChanged(context: Context, intent: Intent) {
        showToast(context, "পাসওয়ার্ড পরিবর্তন করা হয়েছে")
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        showToast(context, "ভুল পাসওয়ার্ড! সতর্কতা")
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent) {
        // সাইলেন্টলি সাকসেস হ্যান্ডেল করুন
    }

    companion object {
        fun getComponentName(context: Context): ComponentName {
            return ComponentName(context.applicationContext, DeviceAdminReceiver::class.java)
        }

        fun isAdminActive(context: Context): Boolean {
            val dpm = getDevicePolicyManager(context)
            return dpm?.isAdminActive(getComponentName(context)) ?: false
        }

        fun enableAdmin(context: Context) {
            if (isAdminActive(context)) {
                showToast(context, "ডিভাইস অ্যাডমিন ইতিমধ্যেই সক্রিয়")
                return
            }

            try {
                val componentName = getComponentName(context)
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName)
                    putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "শিশু সুরক্ষার জন্য ডিভাইস অ্যাডমিন সক্রিয় করুন"
                    )
                }
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } catch (e: Exception) {
                showToast(context, "অ্যাডমিন সক্রিয় করতে ব্যর্থ: ${e.message}")
            }
        }
        
        fun lockDevice(context: Context) {
            if (!isAdminActive(context)) {
                showToast(context, "ডিভাইস অ্যাডমিন সক্রিয় নেই")
                return
            }
            
            try {
                getDevicePolicyManager(context)?.lockNow()
                showToast(context, "ডিভাইস লক করা হয়েছে")
            } catch (e: Exception) {
                showToast(context, "ডিভাইস লক করতে ব্যর্থ: ${e.message}")
            }
        }
        
        fun wipeDevice(context: Context) {
            if (!isAdminActive(context)) {
                showToast(context, "ডিভাইস অ্যাডমিন সক্রিয় নেই")
                return
            }
            
            try {
                getDevicePolicyManager(context)?.wipeData(0)
                showToast(context, "ডিভাইস রিসেট করা হচ্ছে...")
            } catch (e: Exception) {
                showToast(context, "ডিভাইস রিসেট করতে ব্যর্থ: ${e.message}")
            }
        }
        
        private fun getDevicePolicyManager(context: Context): DevicePolicyManager? {
            return try {
                context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            } catch (e: Exception) {
                null
            }
        }
        
        private fun showToast(context: Context, message: String) {
            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        }
    }
}