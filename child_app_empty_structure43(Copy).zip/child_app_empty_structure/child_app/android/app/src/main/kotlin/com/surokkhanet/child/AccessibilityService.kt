package com.surokkhanet.child

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class ChildAccessibilityService : AccessibilityService() {

    private val TAG = "ChildAccessibility"

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "Accessibility service connected")
        
        // ডায়নামিকভাবে সার্ভিস কনফিগারেশন সেট করুন
        val info = AccessibilityServiceInfo().apply {
            // ইভেন্ট টাইপ সেট করুন
            eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED or
                    AccessibilityEvent.TYPE_VIEW_FOCUSED or
                    AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
            
            // ফিডব্যাক টাইপ সেট করুন
            feedbackType = AccessibilityServiceInfo.FEEDBACK_ALL_MASK
            
            // ফ্ল্যাগস সেট করুন
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS or
                    AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE
            
            // নোটিফিকেশন টাইমআউট
            notificationTimeout = 100
        }
        
        this.serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        
        when (event.eventType) {
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                handleNotificationEvent(event)
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                handleWindowChangeEvent(event)
            }
            // অন্যান্য ইভেন্ট টাইপ হ্যান্ডেল করুন
            else -> {
                Log.d(TAG, "Received accessibility event: ${event.eventType}")
            }
        }
    }

    private fun handleNotificationEvent(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString()
        val text = event.text.joinToString(", ")
        
        Log.d(TAG, "Notification from $packageName: $text")
        
        // নোটিফিকেশন ডেটা প্রসেস করুন
        // উদাহরণ: ডেটা সার্ভারে সেন্ড করুন বা লোকাল ডাটাবেসে সেভ করুন
    }

    private fun handleWindowChangeEvent(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString()
        val className = event.className?.toString()
        
        Log.d(TAG, "App changed: $packageName/$className")
        
        // অ্যাপ ব্যবহার মনিটরিং
        // উদাহরণ: বর্তমান অ্যাপ ট্র্যাক করুন
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Log.d(TAG, "Accessibility service unbound")
        return super.onUnbind(intent)
    }
}