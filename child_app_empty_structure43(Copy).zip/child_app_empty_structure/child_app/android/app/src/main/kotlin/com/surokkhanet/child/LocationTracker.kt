package com.surokkhanet.child

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.firebase.database.FirebaseDatabase

object LocationTracker : LocationListener {
    private const val TAG = "LocationTracker"
    private var locationManager: LocationManager? = null
    private var deviceId: String? = null // প্রতিটি ফোনের স্বতন্ত্র আইডি সেভ করার জন্য
    private val db = FirebaseDatabase.getInstance()

    fun startTracking(context: Context) {
        // লোকেশন ব্যবহারের অনুমতি (foreground and background) আছে কিনা তা পরীক্ষা করা হচ্ছে
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_BACKGROUND_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Log.e(TAG, "Location permissions not granted.")
            return // অনুমতি না থাকলে ফাংশন থেকে বেরিয়ে যাবে
        }

        // প্রতিটি ফোনের জন্য স্বতন্ত্র ডিভাইস আইডি নেওয়া হচ্ছে
        this.deviceId = context.getDeviceId()
        locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        try {
            // লোকেশন আপডেট চালু করা হচ্ছে (প্রতি ১০ সেকেন্ডে বা ১০ মিটার পর পর)
            locationManager?.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                10000L, // ১০ সেকেন্ড (10000 মিলিসেকেন্ড)
                10f,    // ১০ মিটার
                this
            )
            Log.d(TAG, "Location tracking started.")
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException: ${e.message}")
        }
    }

    // লোকেশন ট্র্যাকিং বন্ধ করার জন্য এই ফাংশন
    fun stopTracking() {
        locationManager?.removeUpdates(this)
        Log.d(TAG, "Location tracking stopped.")
    }

    override fun onLocationChanged(location: Location) {
        // ডিভাইস আইডি ব্যবহার করে সঠিক পাথে ডেটা সেভ করা হচ্ছে
        deviceId?.let { id ->
            val ref = db.getReference("location/$id")
            val locationData = mapOf(
                "lat" to location.latitude,
                "lng" to location.longitude,
                "timestamp" to System.currentTimeMillis()
            )
            ref.setValue(locationData)
        }
    }

    // এই ফাংশনগুলো LocationListener এর জন্য জরুরি, কিন্তু আমাদের এখানে এগুলোর কোনো কাজ নেই
    override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}

// ডিভাইসের একটি স্বতন্ত্র আইডি (Unique ID) বের করার জন্য এই ফাংশন
@SuppressLint("HardwareIds")
fun Context.getDeviceId(): String {
    return Settings.Secure.getString(
        contentResolver,
        Settings.Secure.ANDROID_ID
    )
}